import React, { useState } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";

const AppLayout = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen((prev) => !prev);
  };

  return (
    <div className="min-h-screen bg-slate-50">

      <Sidebar
        isSidebarOpen={isSidebarOpen}
        toggleSidebar={toggleSidebar}
      />

      {/* Main Content */}
      <div className="md:ml-64 flex flex-col min-h-screen">

        <Header toggleSidebar={toggleSidebar} />

        <main className="flex-1 p-8">
          {children}
        </main>

      </div>

    </div>
  );
};

export default AppLayout;