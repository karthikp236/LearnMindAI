import React, { useEffect, useRef, useState } from "react";
import {
  MessageSquare,
  Send,
  Sparkles,
  Trash2,
} from "lucide-react";import { useParams } from "react-router-dom";
import toast from "react-hot-toast";

import aiService from "../../services/aiService";
import Spinner from "../common/Spinner";
import MarkdownRenderer from "../common/MarkdownRenderer";
import DeleteConfirmModal from "../common/DeleteConfirmModal";
const ChatInterface = () => {
  const { id } = useParams();

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showClearModal, setShowClearModal] = useState(false);

  const messagesEndRef = useRef(null);

  // -----------------------------
  // Scroll to latest message
  // -----------------------------

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // -----------------------------
  // Load chat history
  // -----------------------------

  useEffect(() => {
    fetchChatHistory();
  }, [id]);

  const fetchChatHistory = async () => {
    try {
      setLoading(true);

      const response = await aiService.getChatHistory(id);

      setMessages(response.data || []);
    } catch (error) {
      console.error(error);

      toast.error(
        error.message || "Failed to load chat history"
      );
    } finally {
      setLoading(false);
    }
  };
const handleClearChat = async () => {
    try {
        await aiService.clearChatHistory(id);

        setMessages([]);
        setShowClearModal(false);

        toast.success("Chat cleared successfully!");
    } catch (error) {
        console.error(error);

        toast.error("Failed to clear chat.");
    }
};

  // -----------------------------
  // Send message
  // -----------------------------
  const handleSendMessage = async (e) => {
  e.preventDefault();

  if (!input.trim() || sending) return;

  const question = input.trim();

  // Add user message immediately
  const userMessage = {
    role: "user",
    content: question,
    timestamp: new Date(),
  };

  setMessages((prev) => [...prev, userMessage]);
  setInput("");
  setSending(true);

  try {
    const response = await aiService.chat(id, question);

    const aiMessage = {
      role: "assistant",
      content: response.data?.answer || "No response generated.",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, aiMessage]);
  } catch (error) {
  console.error("Chat Error:", error);

  toast.error(
    error?.error ||
    error?.message ||
    "Failed to send message"
  );

  setMessages((prev) => [
    ...prev,
    {
      role: "assistant",
      content:
        error?.error ||
        error?.message ||
        "Sorry! Something went wrong while generating the response.",
      timestamp: new Date(),
    },
  ]);
}finally {
    setSending(false);
  }
};

// -----------------------------
// Render a single message
// -----------------------------

const renderMessage = (message, index) => {
  const isUser = message.role === "user";

  return (
    <div
      key={index}
      className={`flex ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      <div
        className={`max-w-[80%] rounded-2xl px-5 py-4 shadow-sm ${
          isUser
            ? "bg-emerald-500 text-white"
            : "bg-white border border-slate-200"
        }`}
      >
        {!isUser && (
          <div className="mb-2 flex items-center gap-2">
            <Sparkles
              size={16}
              className="text-emerald-500"
            />

            <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              LearnMind AI
            </span>
          </div>
        )}

        {isUser ? (
          <p className="whitespace-pre-wrap break-words">
            {message.content}
          </p>
        ) : (
          <MarkdownRenderer>
            {message.content}
          </MarkdownRenderer>
        )}

        {message.timestamp && (
          <p className="mt-2 text-right text-[10px] opacity-70">
            {new Date(message.timestamp).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
        )}
      </div>
    </div>
  );
};
// -----------------------------
// Loading State
// -----------------------------

if (loading) {
  return (
    <div className="flex h-[650px] items-center justify-center rounded-3xl bg-white border border-slate-200">
      <Spinner />
    </div>
  );
}

return (
  <div className="flex h-[650px] flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">

    {/* Header */}

 <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">

  <div className="flex items-center gap-3">

    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald-100">
      <MessageSquare
        size={22}
        className="text-emerald-600"
      />
    </div>

    <div>
      <h2 className="text-lg font-semibold text-slate-900">
        AI Learning Assistant
      </h2>

      <p className="text-sm text-slate-500">
        Ask anything related to this document
      </p>
    </div>

  </div>

  <button
onClick={() => setShowClearModal(true)}
    disabled={messages.length === 0}
    className="inline-flex items-center gap-2 rounded-xl border border-red-200 bg-white px-4 py-2 text-sm font-medium text-red-600 transition hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed"
  >
    <Trash2 size={16} />
    Clear Chat
  </button>

</div>

    {/* Messages */}

    <div className="flex-1 overflow-y-auto bg-slate-50 px-6 py-6">

      {messages.length === 0 ? (

        <div className="flex h-full flex-col items-center justify-center text-center">

          <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
            <Sparkles
              size={28}
              className="text-emerald-600"
            />
          </div>

          <h3 className="text-xl font-semibold text-slate-900">
            Start chatting
          </h3>

          <p className="mt-2 max-w-md text-sm text-slate-500">
            Ask questions about your uploaded document and the AI
            will answer using the document content.
          </p>

        </div>

      ) : (

        <div className="space-y-5">

          {messages.map((message, index) =>
            renderMessage(message, index)
          )}

          {sending && (
            <div className="flex justify-start">

              <div className="rounded-2xl border border-slate-200 bg-white px-5 py-4 shadow-sm">

                <div className="flex items-center gap-3">

                  <Spinner />

                  <span className="text-sm text-slate-500">
                    AI is thinking...
                  </span>

                </div>

              </div>

            </div>
          )}

          <div ref={messagesEndRef} />

        </div>

      )}

    </div>

    {/* Input */}

    <form
      onSubmit={handleSendMessage}
      className="border-t border-slate-200 bg-white p-5"
    >

      <div className="flex items-end gap-4">

        <textarea
          rows={2}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask anything about this document..."
          className="flex-1 resize-none rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
        />

        <button
          type="submit"
          disabled={sending || !input.trim()}
          className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white transition hover:scale-105 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Send size={20} />
        </button>

      </div>
<DeleteConfirmModal
  isOpen={showClearModal}
  title="Clear Chat"
  message="Are you sure you want to permanently clear this chat? This action cannot be undone."
  loading={false}
  onConfirm={handleClearChat}
  onCancel={() => setShowClearModal(false)}
/>
    </form>

  </div>
);
};

export default ChatInterface;