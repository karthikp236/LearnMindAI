import React from "react";
import { useNavigate } from "react-router-dom";
import {
  FileText,
  Trash2,
  BookOpen,
  BrainCircuit,
  Clock,
} from "lucide-react";
import moment from "moment";

// Helper function to format file size
const formatFileSize = (bytes) => {
  if (bytes === undefined || bytes === null) return "N/A";

  const units = ["B", "KB", "MB", "GB", "TB"];
  let size = bytes;
  let unitIndex = 0;

  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }

  return `${size.toFixed(1)} ${units[unitIndex]}`;
};

const DocumentCard = ({ document, onDelete }) => {
  const navigate = useNavigate();

  const handleNavigate = () => {
    navigate(`/documents/${document._id}`);
  };

  const handleDelete = (e) => {
    e.stopPropagation();
    onDelete(document);
  };

  return (
    <div
      onClick={handleNavigate}
        className="group w-full rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden"    >
      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center shadow-lg">
            <FileText
              className="w-6 h-6 text-white"
              strokeWidth={2}
            />
          </div>

          <button
            onClick={handleDelete}
            className="opacity-0 group-hover:opacity-100 transition text-slate-400 hover:text-red-500"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        {/* Title */}
        <h3
          className="text-xl font-semibold text-slate-900 truncate"
          title={document.title}
        >
          {document.title}
        </h3>

        {/* Size */}
        <p className="text-sm text-slate-500 mt-2">
          {formatFileSize(document.fileSize)}
        </p>

        {/* Stats */}
        <div className="flex gap-2 mt-5">
          <div className="flex items-center gap-1 rounded-lg bg-purple-50 px-2 py-1">
            <BookOpen
              className="w-3.5 h-3.5 text-purple-600"
              strokeWidth={2}
            />
            <span className="text-[11px] font-semibold text-purple-700">
              {document.flashcardCount} Flashcards
            </span>
          </div>

          <div className="flex items-center gap-1 rounded-lg bg-emerald-50 px-2 py-1">
            <BrainCircuit
              className="w-3.5 h-3.5 text-emerald-600"
              strokeWidth={2}
            />
            <span className="text-[11px] font-semibold text-emerald-700">
              {document.quizCount} Quizzes
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-500">
          <Clock
            className="w-3.5 h-3.5"
            strokeWidth={2}
          />
          <span>
            Uploaded {moment(document.createdAt).fromNow()}
          </span>
        </div>
      </div>
    </div>
  );
};

export default DocumentCard;