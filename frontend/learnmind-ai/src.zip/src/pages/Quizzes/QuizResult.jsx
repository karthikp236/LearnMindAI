import React from "react";
import {
  X,
  CheckCircle,
  XCircle,
  Trophy,
  Target,
  CircleHelp,
} from "lucide-react";

const QuizResult = ({ result, onClose }) => {
  if (!result) return null;

  const quiz = result.quiz;
  const questions = result.results || [];

  const correctAnswers = questions.filter((q) => q.isCorrect).length;
  const wrongAnswers = questions.length - correctAnswers;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm p-4">
      <div className="mx-auto flex h-[92vh] max-w-6xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">

        <div className="sticky top-0 z-10 border-b bg-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="rounded-full bg-emerald-100 p-4">
                <Trophy className="h-8 w-8 text-emerald-600" />
              </div>
              <div>
                <h2 className="text-3xl font-bold">Quiz Results</h2>
                <p className="text-slate-500">{quiz.title}</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="rounded-xl p-2 transition hover:bg-slate-100"
            >
              <X size={24} />
            </button>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="rounded-2xl border bg-emerald-50 p-5 text-center">
              <Target className="mx-auto mb-2 text-emerald-600" />
              <p className="text-sm text-slate-500">Score</p>
              <p className="text-4xl font-bold text-emerald-600">
                {quiz.score}%
              </p>
            </div>

            <div className="rounded-2xl border bg-blue-50 p-5 text-center">
              <CheckCircle className="mx-auto mb-2 text-blue-600" />
              <p className="text-sm text-slate-500">Correct</p>
              <p className="text-4xl font-bold text-blue-600">
                {correctAnswers}
              </p>
            </div>

            <div className="rounded-2xl border bg-red-50 p-5 text-center">
              <XCircle className="mx-auto mb-2 text-red-600" />
              <p className="text-sm text-slate-500">Wrong</p>
              <p className="text-4xl font-bold text-red-600">
                {wrongAnswers}
              </p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {questions.map((item, index) => (
            <div key={index} className="rounded-3xl border bg-white p-6 shadow-sm">
              <div className="mb-5 flex items-start justify-between">
                <div>
                  <span className="rounded-full bg-emerald-100 px-3 py-1 text-sm font-semibold text-emerald-700">
                    Question {index + 1}
                  </span>

                  <h3 className="mt-4 text-xl font-semibold">
                    {item.question}
                  </h3>
                </div>

                {item.isCorrect ? (
                  <CheckCircle className="text-emerald-600" />
                ) : (
                  <XCircle className="text-red-600" />
                )}
              </div>

              <div className="space-y-3">
                {item.options.map((option, i) => {
                  const correct = option === item.correctAnswer;
                  const selected = option === item.selectedAnswer;

                  return (
                    <div
                      key={i}
                      className={`rounded-xl border p-4 transition
                        ${
                          correct
                            ? "border-green-500 bg-green-50"
                            : selected
                            ? "border-red-500 bg-red-50"
                            : "border-slate-200 bg-white"
                        }`}
                    >
                      <div className="flex items-center justify-between">
                        <span>{option}</span>

                        {correct && (
                          <span className="text-sm font-semibold text-green-700">
                            Correct
                          </span>
                        )}

                        {!correct && selected && (
                          <span className="text-sm font-semibold text-red-700">
                            Your Answer
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {item.explanation && (
                <div className="mt-6 rounded-2xl border-l-4 border-blue-500 bg-blue-50 p-5">
                  <div className="mb-2 flex items-center gap-2">
                    <CircleHelp className="text-blue-600" size={18} />
                    <h4 className="font-semibold text-blue-800">
                      Explanation
                    </h4>
                  </div>

                  <p className="leading-7 text-slate-700">
                    {item.explanation}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuizResult;
