// Professional QuizViewer.jsx
import React,{useState} from "react";
import {ChevronLeft,ChevronRight,CheckCircle,X,ClipboardList} from "lucide-react";
import {toast} from "react-hot-toast";
import quizService from "../../services/quizService";

const QuizViewer=({quiz,onClose,onSubmitted})=>{
 const questions=quiz.questions||[];
 const [currentQuestion,setCurrentQuestion]=useState(0);
 const [answers,setAnswers]=useState([]);
 const [selectedOption,setSelectedOption]=useState(null);
 const [loading,setLoading]=useState(false);
 const question=questions[currentQuestion];
 if(!question) return null;

 const handleSelectOption=(option)=>{
   setSelectedOption(option);
   const updated=[...answers];
   const idx=updated.findIndex(a=>a.questionIndex===currentQuestion);
   if(idx>=0) updated[idx]={questionIndex:currentQuestion,selectedAnswer:option};
   else updated.push({questionIndex:currentQuestion,selectedAnswer:option});
   setAnswers(updated);
 };
 const gotoQuestion=(i)=>{
   setCurrentQuestion(i);
   const prev=answers.find(a=>a.questionIndex===i);
   setSelectedOption(prev?.selectedAnswer||null);
 };
 const submit=async()=>{
   if(answers.length!==questions.length){toast.error("Please answer all questions.");return;}
   try{
     
   }catch{}
 };
 const handleSubmit=async()=>{
   if(answers.length!==questions.length){toast.error("Please answer all questions.");return;}
   try{
    setLoading(true);
    await quizService.submitQuiz(quiz._id,answers);
    toast.success("Quiz submitted successfully!");
    onSubmitted();
   }catch(e){
    toast.error("Submission failed.");
   }finally{setLoading(false);}
 };

 return(
 <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm p-4">
  <div className="mx-auto flex h-[92vh] max-w-6xl overflow-hidden rounded-3xl bg-white shadow-2xl">
   <aside className="hidden w-64 border-r bg-slate-50 p-5 lg:block">
    <div className="flex items-center gap-2 font-bold text-lg"><ClipboardList/>Questions</div>
    <div className="mt-5 grid grid-cols-5 gap-2">
      {questions.map((_,i)=>{
        const done=answers.some(a=>a.questionIndex===i);
        return <button key={i} onClick={()=>gotoQuestion(i)} className={`h-10 rounded-lg border font-semibold ${currentQuestion===i?"bg-emerald-600 text-white":done?"bg-emerald-100 border-emerald-400":"bg-white hover:bg-slate-100"}`}>{i+1}</button>
      })}
    </div>
   </aside>
   <div className="flex flex-1 flex-col">
    <div className="border-b bg-white p-6">
      <div className="flex items-center justify-between">
       <div><h2 className="text-2xl font-bold">{quiz.title}</h2><p className="text-slate-500">Question {currentQuestion+1} of {questions.length}</p></div>
       <button onClick={onClose} className="rounded-xl p-2 hover:bg-slate-100"><X/></button>
      </div>
      <div className="mt-5 h-3 rounded-full bg-slate-200">
       <div className="h-full rounded-full bg-emerald-500" style={{width:`${((currentQuestion+1)/questions.length)*100}%`}}/>
      </div>
    </div>
    <div className="flex-1 overflow-y-auto p-8">
      <div className="rounded-3xl border bg-white p-8 shadow-sm">
       <span className="rounded-full bg-emerald-100 px-3 py-1 text-sm font-semibold text-emerald-700">Question {currentQuestion+1}</span>
       <h3 className="mt-5 text-2xl font-semibold">{question.question}</h3>
       <div className="mt-8 space-y-4">
        {question.options.map((option,i)=>(
         <button key={i} onClick={()=>handleSelectOption(option)}
          className={`flex w-full items-center justify-between rounded-2xl border p-5 text-left transition ${selectedOption===option?"border-emerald-500 bg-emerald-50":"hover:border-emerald-300"}`}>
          <span>{option}</span>
          {selectedOption===option && <CheckCircle className="text-emerald-600"/>}
         </button>
        ))}
       </div>
      </div>
    </div>
    <div className="border-t bg-white p-6 flex justify-between">
      <button disabled={currentQuestion===0} onClick={()=>gotoQuestion(currentQuestion-1)} className="flex items-center gap-2 rounded-xl border px-5 py-3 disabled:opacity-50"><ChevronLeft/>Previous</button>
      {currentQuestion===questions.length-1?
      <button onClick={handleSubmit} disabled={loading} className="rounded-xl bg-emerald-600 px-8 py-3 text-white">{loading?"Submitting...":"Submit Quiz"}</button>
      :
      <button onClick={()=>gotoQuestion(currentQuestion+1)} className="flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-3 text-white">Next<ChevronRight/></button>}
    </div>
   </div>
  </div>
 </div>);
};
export default QuizViewer;
