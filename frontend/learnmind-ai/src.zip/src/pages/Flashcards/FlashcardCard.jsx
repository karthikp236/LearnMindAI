import React from "react";
import { BookOpen, Calendar, Trash2 } from "lucide-react";

const FlashcardCard = ({
  flashcardSet,
  onOpen,
  onDelete,
}) => {
  const totalCards = flashcardSet.cards?.length || 0;

  const createdDate = new Date(
    flashcardSet.createdAt
  ).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });

  return (
    <div
      onClick={() => onOpen(flashcardSet)}
      className="group w-full rounded-3xl border border-slate-200 bg-white p-6 shadow-sm transition-all duration-300 hover:border-emerald-300 hover:shadow-lg cursor-pointer"
    >
      {/* Header */}

      <div className="relative">
        {/* Delete Button */}

        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete(flashcardSet._id);
          }}
          className="absolute right-0 top-0 rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
        >
          <Trash2 size={18} />
        </button>

        <div className="flex gap-4 pr-10">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-emerald-100">
            <BookOpen
              size={28}
              className="text-emerald-600"
            />
          </div>

          <div className="flex-1">
<h2 className="text-2xl font-semibold leading-8 text-slate-900 break-words">
                {flashcardSet.title || "Flashcard Set"}
            </h2>

            <div className="mt-2 flex items-center gap-2">
              <Calendar
                size={14}
                className="text-slate-400"
              />

              <span className="text-xs uppercase tracking-wide text-slate-500">
                CREATED {createdDate}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Divider */}

      <div className="my-6 h-px bg-slate-200" />

      {/* Cards Badge */}

      <div className="inline-flex rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-2">
        <span className="text-sm font-medium text-emerald-700">
          {totalCards} Cards
        </span>
      </div>
    </div>
  );
};

export default FlashcardCard;