import React, { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "react-hot-toast";

import AllFlashcardCard from "./AllFlashcardCard";
import FlashcardViewer from "./FlashcardViewer";
import DeleteConfirmModal from "../../components/common/DeleteConfirmModal";

import flashcardService from "../../services/flashcardService";

const AllFlashcards = () => {
  const [flashcardSets, setFlashcardSets] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedSet, setSelectedSet] = useState(null);
  const [showViewer, setShowViewer] = useState(false);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [flashcardToDelete, setFlashcardToDelete] =
    useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchFlashcards = async () => {
    try {
      setLoading(true);

      const response =
        await flashcardService.getAllFlashcardSets();

      if (response.success) {
        setFlashcardSets(response.data);
      } else {
        setFlashcardSets([]);
      }
    } catch (error) {
      console.error(error);

      toast.error(
        error.message ||
          "Failed to load flashcard sets."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFlashcards();
  }, []);

  const handleOpenSet = (set) => {
    setSelectedSet(set);
    setShowViewer(true);
  };

  const handleCloseViewer = () => {
    setSelectedSet(null);
    setShowViewer(false);
  };

  const openDeleteModal = (id) => {
    setFlashcardToDelete(id);
    setShowDeleteModal(true);
  };

  const handleDeleteFlashcard = async () => {
    try {
      setDeleting(true);

      await flashcardService.deleteFlashcardSet(
        flashcardToDelete
      );

      toast.success("Flashcard deleted.");

      setShowDeleteModal(false);
      setFlashcardToDelete(null);

      fetchFlashcards();
    } catch (error) {
      console.error(error);

      toast.error(
        error.message ||
          "Failed to delete flashcard."
      );
    } finally {
      setDeleting(false);
    }
  };

  return (
    <>
      <div className="space-y-8">

        {/* Header */}

        <div>
          <h1 className="text-4xl font-bold text-slate-900">
            All Flashcard Sets
          </h1>

          <p className="mt-2 text-slate-500">
            {flashcardSets.length} set
            {flashcardSets.length !== 1 ? "s" : ""} available
          </p>
        </div>

        {/* Loading */}

        {loading && (
          <div className="flex justify-center py-24">
            <Loader2 className="h-12 w-12 animate-spin text-emerald-600" />
          </div>
        )}

        {/* Empty */}

        {!loading && flashcardSets.length === 0 && (
          <div className="rounded-3xl border border-dashed border-slate-300 bg-white py-24 text-center">
            <h2 className="text-2xl font-semibold">
              No Flashcard Sets
            </h2>

            <p className="mt-3 text-slate-500">
              Upload a document and generate flashcards.
            </p>
          </div>
        )}

        {/* Cards */}

        {!loading && flashcardSets.length > 0 && (
<div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
                    {flashcardSets.map((set) => (
              <AllFlashcardCard
                key={set._id}
                flashcardSet={set}
                onOpen={handleOpenSet}
                onDelete={openDeleteModal}
              />
            ))}
          </div>
        )}
      </div>

      <DeleteConfirmModal
        isOpen={showDeleteModal}
        title="Delete Flashcard Set"
        message="Are you sure you want to delete this flashcard set?"
        loading={deleting}
        onCancel={() => {
          setShowDeleteModal(false);
          setFlashcardToDelete(null);
        }}
        onConfirm={handleDeleteFlashcard}
      />

      {showViewer && selectedSet && (
        <FlashcardViewer
          flashcardSet={selectedSet}
          onClose={handleCloseViewer}
        />
      )}
    </>
  );
};

export default AllFlashcards;