import React, { useEffect, useState } from "react";
import {
  X,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  CheckCircle2,
} from "lucide-react";
import flashcardService from "../../services/flashcardService";

const FlashcardViewer = ({ flashcardSet, onClose }) => {
  const cards = flashcardSet.cards || [];

  const [current, setCurrent] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [completed, setCompleted] = useState(false);

  const card = cards[current];

  const progress =
    cards.length === 0
      ? 0
      : Math.round(((current + 1) / cards.length) * 100);

  useEffect(() => {
    const handleKeyDown = (e) => {
      switch (e.key) {
        case "ArrowRight":
          nextCard();
          break;

        case "ArrowLeft":
          previousCard();
          break;

        case " ":
          e.preventDefault();
          setFlipped((prev) => !prev);
          break;

        case "Escape":
          onClose();
          break;

        default:
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () =>
      window.removeEventListener("keydown", handleKeyDown);
  });

  const nextCard = async () => {
    try {
      // Mark current card as reviewed
      if (card?._id) {
        await flashcardService.reviewFlashcard(card._id);
      }
    } catch (err) {
      console.error("Review update failed:", err);
    }

    if (current === cards.length - 1) {
      setCompleted(true);
      return;
    }

    setCurrent((prev) => prev + 1);
    setFlipped(false);
  };

  const previousCard = () => {
    if (current === 0) return;

    setCurrent((prev) => prev - 1);
    setFlipped(false);
  };

  const restart = () => {
    setCompleted(false);
    setCurrent(0);
    setFlipped(false);
  };

  if (completed) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
        <div className="w-full max-w-lg rounded-3xl bg-white p-10 text-center shadow-2xl">
          <CheckCircle2 className="mx-auto h-20 w-20 text-emerald-600" />

          <h2 className="mt-6 text-3xl font-bold">
            Session Completed 🎉
          </h2>

          <p className="mt-3 text-slate-500">
            You've reviewed all flashcards.
          </p>

          <div className="mt-8 flex justify-center gap-4">
            <button
              onClick={restart}
              className="rounded-xl border px-6 py-3 hover:bg-slate-100"
            >
              Study Again
            </button>

            <button
              onClick={onClose}
              className="rounded-xl bg-emerald-600 px-6 py-3 text-white hover:bg-emerald-700"
            >
              Back to Flashcards
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-6">
      <div className="w-full max-w-4xl rounded-3xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-8 py-6">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">
              {flashcardSet.title || "Flashcard Set"}
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Card {current + 1} of {cards.length}
            </p>
          </div>

          <button
            onClick={onClose}
            className="rounded-xl p-2 transition hover:bg-slate-100"
          >
            <X size={24} />
          </button>
        </div>

        <div className="px-8 pt-6">
          <div className="mb-2 flex items-center justify-between text-sm text-slate-500">
            <span>Progress</span>
            <span>{progress}%</span>
          </div>

          <div className="h-2 overflow-hidden rounded-full bg-slate-200">
            <div
              className="h-full rounded-full bg-emerald-500 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="px-8 py-8">
          <div
            onClick={() => setFlipped(!flipped)}
            className="flex h-[380px] cursor-pointer flex-col items-center justify-center rounded-3xl border-2 border-emerald-200 bg-gradient-to-br from-white to-emerald-50 p-10 text-center shadow-lg transition hover:shadow-xl"
          >
            <span className="mb-6 rounded-full bg-emerald-100 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-emerald-700">
              {flipped ? "Answer" : "Question"}
            </span>

            <h2 className="max-w-3xl text-3xl font-bold leading-relaxed text-slate-800">
              {flipped ? card.answer : card.question}
            </h2>

            <p className="mt-8 text-sm text-slate-400">
              Click anywhere on the card or press <b>Space</b> to flip
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between border-t border-slate-200 px-8 py-6">
          <button
            onClick={previousCard}
            disabled={current === 0}
            className="flex items-center gap-2 rounded-xl border px-5 py-3 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <ChevronLeft size={18} />
            Previous
          </button>

          <button
            onClick={() => setFlipped(!flipped)}
            className="flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 font-medium text-white transition hover:bg-slate-800"
          >
            <RotateCcw size={18} />
            Flip Card
          </button>

          <button
            onClick={nextCard}
            className="flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-3 font-medium text-white transition hover:bg-emerald-700"
          >
            {current === cards.length - 1 ? "Finish" : "Next"}
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default FlashcardViewer;