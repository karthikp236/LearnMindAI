import React, { useState, useEffect } from "react";
import Spinner from "../../components/common/Spinner";
import progressService from "../../services/progressService";
import toast from "react-hot-toast";
import {
  FileText,
  BookOpen,
  BrainCircuit,
  TrendingUp,
  Clock,
} from "lucide-react";

const DashboardPage = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const response = await progressService.getDashboardData();

        console.log("Dashboard Data:", response);

        setDashboardData(response.data);
      } catch (error) {
        console.error(error);
        toast.error("Failed to fetch dashboard data");
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const formatDate = (date) => {
    if (!date) return "Recently";

    const d = new Date(date);

    if (isNaN(d.getTime())) return "Recently";

    return d.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  // Greeting based on time
  const getGreeting = () => {
    const hour = new Date().getHours();

    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  };

  // Greeting icon
  const getGreetingIcon = () => {
    const hour = new Date().getHours();

    if (hour < 12) return "🌅";
    if (hour < 17) return "☀️";
    return "🌙";
  };

  if (loading) {
    return <Spinner />;
  }

  if (!dashboardData?.overview) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <TrendingUp
            className="mx-auto text-slate-300 mb-4"
            size={52}
          />

          <h2 className="text-xl font-semibold text-slate-800">
            No dashboard data
          </h2>

          <p className="text-slate-500 mt-2">
            Upload your first document to get started.
          </p>
        </div>
      </div>
    );
  }

  const stats = [
    {
      title: "TOTAL DOCUMENTS",
      value: dashboardData.overview.totalDocuments || 0,
      icon: FileText,
      color: "from-blue-500 to-cyan-500",
    },
    {
      title: "TOTAL FLASHCARDS",
      value: dashboardData.overview.totalFlashcards || 0,
      icon: BookOpen,
      color: "from-pink-500 to-purple-500",
    },
    {
      title: "TOTAL QUIZZES",
      value: dashboardData.overview.totalQuizzes || 0,
      icon: BrainCircuit,
      color: "from-emerald-500 to-green-500",
    },
  ];
  return (
  <div className="min-h-full relative">
    {/* Background */}
    <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle,#e5e7eb_1px,transparent_1px)] bg-[length:22px_22px] opacity-60" />

    <div className="max-w-7xl mx-auto px-8 py-8">

      {/* Welcome Banner */}
      <div className="mb-8 rounded-3xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 shadow-xl overflow-hidden">
        <div className="flex items-center justify-between px-8 py-8">

          <div>
            <p className="uppercase tracking-[0.3em] text-sm text-emerald-100 font-semibold">
              LearnMind AI
            </p>

            <h1 className="mt-3 text-4xl font-bold text-white">
              {getGreeting()}{" "}
              <span className="text-yellow-200">
                {dashboardData?.user?.username || "Learner"}
              </span>{" "}
              {getGreetingIcon()}
            </h1>

            <p className="mt-3 text-emerald-100 text-lg">
              Ready to continue your AI-powered learning journey today?
            </p>
          </div>

          {/* Avatar */}
          <div className="hidden md:flex items-center justify-center w-20 h-20 rounded-full bg-white/20 backdrop-blur border border-white/30 text-white text-3xl font-bold shadow-lg">
            {(dashboardData?.user?.username || "L")
              .charAt(0)
              .toUpperCase()}
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
        {stats.map((item, index) => {
          const Icon = item.icon;

          return (
            <div
              key={index}
              className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden"
            >
              <div className="flex items-center justify-between p-6">
                <div>
                  <p className="text-xs uppercase tracking-widest font-semibold text-slate-500">
                    {item.title}
                  </p>

                  <h2 className="mt-3 text-4xl font-bold text-slate-900">
                    {item.value}
                  </h2>
                </div>

                <div
                  className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${item.color} flex items-center justify-center shadow-md`}
                >
                  <Icon className="w-7 h-7 text-white" />
                </div>
              </div>

              <div
                className={`h-1 bg-gradient-to-r ${item.color}`}
              />
            </div>
          );
        })}
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                {/* Section Header */}
        <div className="flex items-center gap-4 px-6 py-5 border-b border-slate-200">
          <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center">
            <Clock className="w-5 h-5 text-slate-600" />
          </div>

          <div>
            <h2 className="text-xl font-semibold text-slate-900">
              Recent Activity
            </h2>

            <p className="text-sm text-slate-500">
              Your latest learning activities
            </p>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {dashboardData?.recentActivity?.length ? (
            dashboardData.recentActivity.map((activity) => (
              <div
                key={activity._id}
                className="flex items-center px-6 py-5 hover:bg-slate-50 transition-all duration-200"
              >
                <div className="flex items-center gap-4">

                  {/* Activity Icon */}
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      activity.type === "document"
                        ? "bg-blue-100"
                        : "bg-emerald-100"
                    }`}
                  >
                    {activity.type === "document" ? (
                      <FileText className="w-6 h-6 text-blue-600" />
                    ) : (
                      <BrainCircuit className="w-6 h-6 text-emerald-600" />
                    )}
                  </div>

                  {/* Activity Details */}
                  <div>
                    <h3 className="text-base font-semibold text-slate-900">
                      {activity.title}
                    </h3>

                    <p className="text-sm text-slate-500 mt-1">
                      {formatDate(activity.createdAt)}
                    </p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-20">

              <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mb-6">
                <FileText className="w-10 h-10 text-slate-400" />
              </div>

              <h3 className="text-xl font-semibold text-slate-900">
                No Activity Yet
              </h3>

              <p className="mt-2 max-w-md text-center text-slate-500">
                Upload your first document to start generating summaries,
                flashcards, and quizzes.
              </p>

            </div>
          )}
        </div>
      </div>
    </div>
  </div>
);

};

export default DashboardPage;